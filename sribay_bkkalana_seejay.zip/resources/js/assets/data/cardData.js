export default [
   {
      image:"/static/images/mobile.jpg",
      path: "/products/gadgets/111"
   },
   {
      image:"/static/images/sports.jpg",
      path: "/products/men/103"
   },
   {
      image:"/static/images/headphone.jpg",
      path: "/products/gadgets/101"
   },
   {
      image:"/static/images/t-shirts.jpg",
      path: "/products/men/105"
   },
   {
      image:"/static/images/watch.jpg",
      path: "/products/gadgets/112"
   },
   {
      image:"/static/images/shoes.jpg",
      path: "/products/men/101"
   }
]