export default [
   {
      image:"/static/images/user-1.jpg",
      name:"Lissa Roy",
      email:"lissa@example.com",
      access:"Read"
   },
   {
      image:"/static/images/user-2.jpg",
      name:"Ritesh Bajaj",
      email:"ritesh@example.com",
      access:"Write"
   },
   {
      image:"/static/images/user-3.jpg",
      name:"Dimple Bhagtani",
      email:"dimple@example.com",
      access:"Admin"
   },
   {
      image:"/static/images/user-4.jpg",
      name:"Sam Akhtar",
      email:"akhtar@example.com",
      access:"Admin"
   }
]