export default [
   {
      id:1,
      image: "static/images/collection.jpg",
      subHeading: "Latest Collections",
      offer: "Save Upto 60%"
   },
   {
      id:2,
      image: "static/images/col-men.jpg",
      subHeading: "Mens Collectionns",
      offer: "Save Upto 60%"
   },
   {
      id:3,
      image: "static/images/col-women.jpg",
      subHeading: "Women's Collections",
      offer: "Save Upto 60%"
   },
   {
      id:4,
      image: "static/images/col-watches.jpgg",
      subHeading: "Watches Collections",
      offer: "Save Upto 60%"
   },
   {
      id:5,
      image: "static/images/col-accessories.jpg",
      subHeading: "Accessories Collections",
      offer: "Save Upto 60%"
   }
]