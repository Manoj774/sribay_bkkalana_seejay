export default [
    {
        image: "/static/images/free-delivery.png",
        subTitle: "FREE SHIPPING",
        title: "Every Day, Every Order",
        desc: "*All order over $100"
    },
    {
        image: "/static/images/customer-support.png",
        subTitle: "FRIENDLY SUPPORT",
        title: "24/7 Dedicated Support",
        desc: "*Only In USA"
    },
    {
        image: "/static/images/money-back.png",
        subTitle: "SECURE",
        title: "Money Back Guranteed",
        desc: "*Conditions Apply"
    }
]
