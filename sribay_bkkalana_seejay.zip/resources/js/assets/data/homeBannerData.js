export default [
    {
        image: "/static/images/slider-1.jpg",
        subHeading: "Big Sale",
        heading: "Women's Collection",
        link: "SHOP NOW",
        routeSubTitle:"women"
    },
    {
        image: "/static/images/slider-2.jpg",
        subHeading: "50% OFF",
        heading: "Men's Winter Collection",
        link: "SHOP NOW",
        routeSubTitle:"men"
    },
    {
        image: "/static/images/slider-3.jpg",
        subHeading: "Today's Special",
        heading: "Sale on Jacket",
        link: "SHOP NOW",
        routeSubTitle:"men"
    }
]