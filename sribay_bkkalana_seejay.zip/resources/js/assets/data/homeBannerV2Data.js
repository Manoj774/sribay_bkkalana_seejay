export default [
   {
      image: "static/images/home2-slider-1.jpg",
      subHeading: "New Arrival",
      heading: "Biggest Sale",
      percent:"50%",
      offer: "Flat Off"
   },
   {
      image: "static/images/home2-slider-2.jpg",
      subHeading: "Women's Special",
      heading: "Winter Sale",
      percent:"40%",
      offer: "Off"
   },
   {
      image: "static/images/home2-slider-3.jpg",
      subHeading: "Special Deal",
      heading: "Mens Collection",
      percent:"30%",
      offer: "Off"
   },
   {
      image: "static/images/home2-slider-4.jpg",
      subHeading: "Sunglasses",
      heading: "Weekly Offer",
      percent:"30%",
      offer: "Off"
   },
   {
      image: "static/images/home2-slider-5.jpg",
      subHeading: "New Arrival",
      heading: "Sport Shoe",
      percent:"50%",
      off: "Flat Off"
   },
   {
      image: "static/images/home2-slider-6.jpg",
      subHeading: "Accessories",
      heading: "Smart Offer",
      percent:"40%",
      off: "Flat Off"
   }
]