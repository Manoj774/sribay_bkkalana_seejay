export default [
   {
      image: "/static/images/cat-shoes.jpg",
      name: "Men White AIR",
      category: "Shoes",
      offer: "UPTO 20% OFF"
   },
   {
      image: "/static/images/women/9-item-a.jpg",
      name: "White T-Shirt",
      category: "T-Shirt",
      offer: "UPTO 20% OFF"
   },
   {
      image: "/static/images/gadgets/g-5-a.jpg",
      name: "Circular Speaker",
      category: "Speaker",
      offer: "UPTO 20% OFF"
   },
   {
      image: "/static/images/accessroies/a-5-a.jpg",
      name: "Summer Goggles",
      category: "Glasses",
      offer: "UPTO 20% OFF"
   },
]