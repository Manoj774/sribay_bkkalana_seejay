export default[
   "/static/images/client-logo-2.png",
   "/static/images/client-logo-3.png",
   "/static/images/client-logo-4.png",
   "/static/images/client-logo-5.png",
   "/static/images/client-logo-2.png",
   "/static/images/client-logo-3.png",
   "/static/images/client-logo-4.png"
]