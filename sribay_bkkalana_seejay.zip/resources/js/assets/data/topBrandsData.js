export default[
   "/static/images/topbrands/client-logo-1.png",
   "/static/images/topbrands/client-logo-2.png",
   "/static/images/topbrands/client-logo-3.png",
   "/static/images/topbrands/client-logo-4.png",
   "/static/images/topbrands/client-logo-5.png",
   "/static/images/topbrands/client-logo-2.png",
   "/static/images/topbrands/client-logo-3.png",
   "/static/images/topbrands/client-logo-4.png"
]