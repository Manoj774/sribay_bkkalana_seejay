export default [
   {
      objectID: 2,
      image: "/static/images/men/2-item-a.jpg",
      name: "Super Jacket",
      category: "Jacket",
      price: "82.75"
   },
   {
      objectID: 1,
      image: "/static/images/men/3-item-a.jpg",
      name: "Vintage Jean",
      category: "Jean",
      price: "18.75"
   },
   {
      objectID: 91,
      image: "/static/images/men/1-item-a.jpg",
      name: "Shirt",
      category: "Denim Pullover",
      price: "42.75"
   },
   {
      objectID: 92,
      image: "/static/images/men/5-item-a.jpg",
      name: "Black-T-Shirt",
      category: "Shirt",
      price: "22.75"
   },
   {
      objectID: 3,
      image: "/static/images/men/4-item-a.jpg",
      name: "Blue-Jean",
      category: "Jeans",
      price: "40.82"
   },
   {
      objectID: 8,
      image: "/static/images/women/6-item-a.jpg",
      name: "Red Dress",
      category: "Dresses",
      price: "97.75"
   },
   {
      objectID: 890,
      image: "static/images/cat-shoes.jpg",
      name: "Men White AIR",
      category: "Shoes",
      price: "65.75"
   },
   {
      objectID: 891,
      image: "/static/images/accesories/a-2-a.jpg",
      name: "Men Belt",
      category: "Belts",
      price: "38.31"
   },
   {
      objectID: 892,
      image: "/static/images/gadgets/g-2-a.jpg",
      name: "Black Smartphone",
      category: "Smartphone",
      price: "538.31"
   },
   {
      objectID: 893,
      image: "/static/images/gadgets/g-1-a.jpg",
      name: "Headphone",
      category: "Wired Headphone",
      price: "125.75"
   },
   {
      objectID: 894,
      image: "/static/images/women/10-item-a.jpg",
      name: "Striped Pullover",
      category: "Sweater",
      price: "49.75"
   },
   {
      objectID: 895,
      image: "/static/images/accesories/a-3-a.jpg",
      name: "Jewellery",
      category: "Steel Chain",
      price: "38.31"
   },
]