<template>
   <div class="d-inline-block social-icons">
      <v-btn light icon class="primary">
         <v-icon light>fa-facebook</v-icon>
      </v-btn>
      <v-btn light icon class="primary">
         <v-icon light>fa-twitter</v-icon>
      </v-btn>
      <v-btn light icon class="primary">
         <v-icon light> fa-google-plus</v-icon>
      </v-btn>
      <v-btn light icon class="primary">
         <v-icon light>fa-instagram</v-icon>
      </v-btn>
   </div>
</template>