<template>
   <div class="cta-single-banner section-gap pt-0">
      <div class="container">
         <div class="cta text-center">
            <div class="overlay-section-overlay cta-image">
            <img src="static/images/bg-sunglass.jpg" alt="banner-image">
            <div class="cta-content">
               <p>
                  <v-icon color="white">brightness_5</v-icon>
               </p>
               <h4 class="font-weight-bold mb-6 white--text">new arrival</h4>
               <h2 class="mb-6 white--text">Sunglasses for Everyone</h2>
               <v-btn class="my-0" to="/products">SHOP NOW</v-btn>
            </div>
            </div>
         </div>
      </div>
   </div>
</template>
