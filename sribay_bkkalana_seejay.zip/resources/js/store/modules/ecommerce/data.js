// this  data is used for cart content
export const cart = []

// this data is used for wishlist
export const wishlist = []
