<template>

</template>

<script>
    export default {
        name: "MemberDetails"
    }
</script>

<style scoped>

</style>
