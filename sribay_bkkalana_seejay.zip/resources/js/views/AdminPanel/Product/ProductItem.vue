<template>
    <div>
        <div class="product-item-wrap emb-card"  style="max-height: 400px; min-height: 400px;">
            <div class="thumb-warp">
                <img alt="product" :src="data.image" style="max-height: 280px;min-height: 280px;">

                <div class="wishlist-icon">
                    <v-btn @click="deleteItem(data)" icon >
                        <v-icon class="grey--text">mdi-delete</v-icon>
                    </v-btn>
                </div>

                <router-link :to="'/sriBay-admin/product-edit/'+data.id">
                    <div class="add-to-cart">
                        <v-btn
                            class="accent"
                            small icon
                        >
                            <v-icon>mdi-pencil</v-icon>
                        </v-btn>
                    </div>
                </router-link>

            </div>
            <div class="emb-card-content pa-4">
                <h5 class="font-weight-medium text-capitalize">{{data.name.substring(0,50)+'....'}}</h5>
                <div class="inline-block">
                    <p>{{data.category}}</p>
                </div>
                <div class="emb-meta-info layout align-center justify-space-between">
                    <div class="inline-block">
                        <h6 class="accent--text">
                            <emb-currency-sign></emb-currency-sign>{{data.price}}
                        </h6>
                    </div>
                </div>
            </div>
        </div>
        <emb-delete-confirmation-2
            ref="deleteConfirmationDialog"
            messageTitle="Are You Sure You Want To Delete?"
            messageDescription="Are you sure you want to delete this product permanently?"
            @onConfirm="onDeleteItemFromProductsList"
            btn1="Cancel"
            btn2="Yes"
        >
        </emb-delete-confirmation-2>
    </div>
</template>

<script>
export default {
  props: ["data", "deleteProduct"],
  data() {
    return {
      selectedItem: null
    };
  },
  methods: {
    deleteItem(data) {
      this.$refs.deleteConfirmationDialog.openDialog();
      this.selectedItem = data;
    },
    onDeleteItemFromProductsList() {
        this.$refs.deleteConfirmationDialog.close();
        axios.delete('/api/product/'+this.selectedItem.id).then(response => {
            this.$snotify.success(response.data.message, {
                closeOnClick: false,
                pauseOnHover: false,
                timeout: 1000,
                showProgressBar: false,
            });
            setTimeout(() => {
                window.location.href='';
            }, 2000);

        }, err => {
            const errors = err.response.data.message;
            let html = '';
            for (const i in errors){
                html += errors[i];
            }
            this.$toast.open({
                message: html,
                type: 'error',
            });
        });

    }
  }
};
</script>
